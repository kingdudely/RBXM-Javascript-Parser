import { DataTypes } from "./Constants.js";

const radiansToDegrees = 180 / Math.PI;
function rotationMatrixToEulerAngles(m) {
	const [m0,,, m3,,, m6, m7, m8] = m;

	const
		x = Math.atan2(m7, m8),
		y = Math.atan2(-m6, Math.hypot(m7, m8)),
		z = Math.atan2(m3, m0);

	return [x * radiansToDegrees, y * radiansToDegrees, z * radiansToDegrees];
};

export default function CreatePropertyValueReader(PROPReader, dataTypeID) {
    const DataType = DataTypes[dataTypeID];
    console.assert(DataType != null, "Unknown data type, ID " + dataTypeID);

    switch (DataType) {
        case "String": return () => PROPReader.readString(PROPReader.getUint32(true));

        default: return () => {};
    };
};