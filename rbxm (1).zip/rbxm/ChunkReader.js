// Chunk:
// Signature: [4]getUint8 - Type of chunk and structure of data
// CompressedLength: getUint32 - Length of the data
// UncompressedLength: getUint32 - Length of the data after decompression
// Reserved: [4]getUint8 - Reserved for future use
// Data: []getUint8 - The data
// Chunks are compressed using LZ4
// If the chunk is not compressed, CompressedLength == 0 and UncompressedLength == the length of the data

import LZ4BlockJS from "./lz4.js";
import ByteEditor from "./ByteEditor.js";

export default function GetChunkReader(Reader) {
	const chunkSignature = Reader.readString(4);

	const compressedLength = Reader.getUint32(true);
	const uncompressedLength = Reader.getUint32(true);
	const dataLength = compressedLength || uncompressedLength;

	Reader.move(4); // Reserved

	// might be incorrectly copying the chunk payload?
	const chunkData = Reader.readBytes(dataLength);

	const decompressedData = compressedLength
		? LZ4BlockJS.prototype.decodeBlock(chunkData, 0, uncompressedLength)
		: chunkData;

	const chunkReader = new ByteEditor(decompressedData.buffer);

	return {
		Signature: chunkSignature,
		Reader: chunkReader,
	};
}
