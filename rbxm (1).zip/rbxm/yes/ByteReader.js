const byteSizes = {
	getInt8: 1,
	getUint8: 1,
	getInt16: 2,
	getUint16: 2,
	getInt32: 4,
	getUint32: 4,
	getFloat32: 4,
	getFloat64: 8,
	getBigInt64: 8,
	getBigUint64: 8,
};

const zigzagDecode = v => (v >> 1) ^ (-(v & 1));

function decodeCustomFloat(n) {
	const exponent = n >>> 24;
	if (exponent === 0)
		return 0;

	const floatNum =
		Math.pow(2, exponent - 127) * (1 + ((n >>> 1) & 0x7fffff) / 0x7fffff);

	return n & 1 ? -floatNum : floatNum;
}

class ByteReaderError extends RangeError {
	constructor(offset, size, length) {
		super(`Attempt to read beyond buffer length: offset ${offset}, size ${size}, length ${length}`);
		this.name = "ByteReaderError";
		this.offset = offset;
		this.size = size;
		this.length = length;
	}
}

export default class ByteReader extends DataView {
	#offset = 0;

	constructor(buffer, byteOffset = 0, byteLength) {
		super(buffer, byteOffset, byteLength);
	}

	get byteOffset() {
		return this.#offset;
	}

	set byteOffset(value) {
		value = Number(value);

		if (isNaN(value) || value < 0 || value > this.byteLength) {
			throw new RangeError(`Invalid byteOffset: ${value}. Must be >= 0 and <= ${this.byteLength}`);
		};

		this.#offset = value;
	}

	// Override all simple getters dynamically
	// (handles littleEndian argument transparently)
}

for (const [name, size] of Object.entries(byteSizes)) {
	ByteReader.prototype[name] = function(...args) {
		if (this.byteOffset + size > this.byteLength)
			throw new ByteReaderError(this.byteOffset, size, this.byteLength);

		const currentOffset = this.byteOffset;
		this.byteOffset += size;

		// Call DataView method with absolute offset and pass all other args (like littleEndian)
		return DataView.prototype[name].call(this, currentOffset, ...args);
	};
}

ByteReader.prototype.getInterleavedUint8 = function(length, callback) {
	const result = new Array(length);

	if (typeof callback === "function")
		for (let i = 0; i < length; i++)
			result[i] = callback(this.getUint8());
	else
		for (let i = 0; i < length; i++)
			result[i] = this.getUint8();

	return result;
};

ByteReader.prototype.getInterleavedInt8 = function(length) {
	const result = this.getInterleavedUint8(length);

	for (let i = 0; i < length; i++)
		result[i] = zigzagDecode(result[i]);

	return result; // this.getInterleavedUint8(length).map(zigzagDecode);
};

ByteReader.prototype.getInterleavedUint32 = function(length, callback) {
	const startOffset = this.byteOffset;
	const results = new Array(length);
	const byteTotal = length * 4;

	if (startOffset + byteTotal > this.byteLength)
		throw new ByteReaderError(startOffset, byteTotal, this.byteLength);

	// Helper to read interleaved uint32
	const readInterleavedUint32 = index => {
		return (
			(this.getUint8(startOffset + index) << 24) +
			(this.getUint8(startOffset + ((index + length) % byteTotal)) << 16) +
			(this.getUint8(startOffset + ((index + length * 2) % byteTotal)) << 8) +
			this.getUint8(startOffset + ((index + length * 3) % byteTotal))
		);
	};


	if (typeof callback === "function")
		for (let i = 0; i < length; i++)
			result[i] = callback(readInterleavedUint32(i));
	else
		for (let i = 0; i < length; i++)
			result[i] = readInterleavedUint32(i);

	this.byteOffset += byteTotal;

	return results;
};

ByteReader.prototype.getInterleavedInt32 = function (length) {
	return this.getInterleavedUint32(length, zigzagDecode);
};

ByteReader.prototype.getInterleavedFloat32 = function (length) {
	return this.getInterleavedUint32(length, decodeCustomFloat);
};