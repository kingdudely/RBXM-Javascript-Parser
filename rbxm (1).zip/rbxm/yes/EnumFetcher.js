import { getAPIDump } from "/modules/utilities.js";

const ApiDump = await getAPIDump();
const { Classes, Enums } = ApiDump;

if (
	ApiDump == null ||
	Classes == null ||
	Enums == null
) throw new Error("Invalid API dump");

// https://setup.rbxcdn.com/version-4672a50031594039-Full-API-Dump.json
// https://clientsettings.roblox.com/v2/client-version/WindowsStudio64/channel/LIVE

/**
 * Gets the enum's name from a property name and class name
 * @param {string} propertyName Property name
 * @param {string} className Class name
 * @returns
 */
export function getEnumName(propertyName, className) {
	for (const Class of Classes) {
		if (Class.Name.toLowerCase() === className.toLowerCase()) {
			const { Members, Superclass } = Class;

			for (const Member of Members) {
				const { MemberType, ValueType } = Member;

				if (
					MemberType === "Property" &&
					Member.Name.toLowerCase() === propertyName.toLowerCase() &&
					ValueType.Category === "Enum"
				) {
					return ValueType.Name;
				}
			};

			if (Superclass && Superclass !== "<<<ROOT>>>") {
				return getEnumName(propertyName, Class.Superclass);
			};
		};
	};
};

/**
 * Gets the enum's name as a string from it's numerical value
 * @param {string} enumName Enum name
 * @param {number} value The numerical value of the enum
 * @returns
 */
export function getEnumValue(enumName, value) {
	for (const Enum of Enums) {
		const { Items } = Enum;

		if (Enum.Name.toLowerCase() == enumName.toLowerCase()) {
			for (const Item of Items) {
				if (Item.Value === value) {
					return Item.Name;
				}
			}
		}
	}
}
