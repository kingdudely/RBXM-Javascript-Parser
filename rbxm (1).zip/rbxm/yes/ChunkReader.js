// Chunk:
// Signature: [4]uint8 - Type of chunk and structure of data
// CompressedLength: uint32 - Length of the data
// UncompressedLength: uint32 - Length of the data after decompression
// Reserved: [4]uint8 - Reserved for future use
// Data: []uint8 - The data
// Chunks are compressed using LZ4
// If the chunk is not compressed, CompressedLength == 0 and UncompressedLength == the length of the data

// var lz4 = require("lz4js");
import LZ4BlockJS from "./lz4.js";
import ByteReader from "./ByteReader.js";

/**
 * Reads a chunk of data
 * @param {DataView} chunk
 */
export default function ReadChunk(reader) {
	const Signature = String.fromCharCode(
		reader.getUint8(),
		reader.getUint8(),
		reader.getUint8(),
		reader.getUint8(),
	);

	const compressedLength = reader.getUint32(true);
	const uncompressedLength = reader.getUint32(true);
	// const compressedIsEmpty = compressedLength === 0;
	const dataLength = compressedLength || uncompressedLength;
	reader.byteOffset += 4;

	// might be incorrectly copying the chunk payload?
	/*
	const chunkData = new Uint8Array(dataLength);
	for (var i = 0; i < dataLength; i++) {
		chunkData[i] = reader.uint8();
	}
	*/
	const chunkData = new Uint8Array(reader.buffer, reader.byteOffset, dataLength);
	reader.byteOffset += dataLength;

	// Decompress the data if it is compressed
	const decompressedData = compressedLength
		? LZ4BlockJS.prototype.decodeBlock(chunkData, 0, uncompressedLength)
		: chunkData;

	const Payload = new ByteReader(decompressedData.buffer);

	return {
		Signature,
		Payload,
	};
}
