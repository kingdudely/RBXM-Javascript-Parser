import {
	ReadPropertyValue,
	ReadReferences,
	ReadString,
} from "./BinaryTypeReader.js";
import ByteReader from "./ByteReader.js";
import ReadChunk from "./ChunkReader.js";
import { arraysEqual } from "../utilities.js";

// Decoding roblox binary files
// Starts with a signature of type [14]uint8
// Then a version of type uint16
// Then the content

// Header:
// ClassCount: uint32 - The number of unique classes in the file
// InstanceCount: uint32 - The number of instances in the file
// Reserved: [8]uint8 - Reserved for future use

// Chunk:
// Signature: [4]uint8 - Type of chunk and structure of data
// CompressedLength: uint32 - Length of the data
// UncompressedLength: uint32 - Length of the data after decompression
// Reserved: [4]uint8 - Reserved for future use
// Data: []uint8 - The data
// Chunks are compressed using LZ4
// If the chunk is not compressed, CompressedLength == 0 and UncompressedLength == the length of the data

// Chunks:
// META:
// Length: uint32 - The amount of entries
// Entries: []Entry
// Entry:
// Key: string - The key of the entry
// Value: string - The value of the entry

// SSTR:
// Version: int32 - The version of the chunk
// Length: uint32 - The amount of strings
// Strings: []SharedStringValue - The strings
// SharedStringValue:
// Hash: [16]uint8 - The hash of the string
// Value: string - The value of the string

// INST:
// ClassID: int32 - The class ID of the instance
// ClassName: string - The name of the class
// HasService: bool - Whether the chunk has service data
// Length: uint32 - The amount of instances
// IDs: References - The instances
// IsService: ?[]bool - Whether the instance is a service

const Signature = [
	0x3c, 0x72, 0x6f, 0x62, 0x6c, 0x6f, 0x78, 0x21, 0x89, 0xff, 0x0d, 0x0a, 0x1a,
	0x0a,
];

export function decode(buffer) {
	const Game = {};
	const Metadata = {};
	const start = performance.now();
	const Reader = new ByteReader(buffer);

	// Validate file signature
	for (let i = 0; i < Signature.length; i++) {
		if (Reader.getUint8() !== Signature[i]) {
			throw new Error("Invalid file signature.");
		}
	}

	// Read version and header
	Metadata.Version = Reader.getUint16(true);
	Metadata.ClassCount = Reader.getUint32(true);
	Metadata.InstanceCount = Reader.getUint32(true);
	Reader.byteOffset += 8; // Skip reserved bytes

	const Instances = [];
	const Classes = {};
	let Chunk;

	while (true) {
		Chunk = ReadChunk(Reader);
		const { Payload, Signature } = Chunk;

		if (Signature === "END\x00") break;

		switch (Signature) {
			case "META": {
				const length = Payload.getUint32(true);
				for (let i = 0; i < length; i++) {
					const key = ReadString(Payload);
					const value = ReadString(Payload);
					Metadata[key] = value;
				}
				break;
			}

			case "SSTR":
				// Currently unused
				break;

			case "INST": {
				const ClassID = Payload.getInt32(true);
				const ClassName = ReadString(Payload);
				const HasService = Payload.getUint8();
				const InstanceCount = Payload.getUint32(true);
	
if (InstanceCount < 0 || InstanceCount > 1000000) {  // choose reasonable upper bound
  throw new Error(`Invalid InstanceCount: ${InstanceCount}`);
}

				const InstanceIDs = ReadReferences(Payload, InstanceCount);

				const IsService = new Array(InstanceCount);
				for (let i = 0; i < InstanceCount; i++) {
					IsService[i] = Payload.getUint8() === 1;
				}

				Classes[ClassID] = {
					ClassName,
					Instances: [],
				};

				let InstanceID = 0;
				for (let i = 0; i < InstanceCount; i++) {
					InstanceID += InstanceIDs[i];
					Instances[InstanceID] = {
						ClassName,
						Children: [],
					};
					Classes[ClassID].Instances.push(InstanceID);
				}

				break;
			}

			case "PROP": {
				const ClassID = Payload.getInt32(true);
				const PropertyName = ReadString(Payload);

				const Value = ReadPropertyValue(
					Payload,
					Classes[ClassID].Instances.length,
					Classes[ClassID].ClassName,
					PropertyName
				);

				if (Value.values) {
					let propName = PropertyName.charAt(0).toUpperCase() + PropertyName.slice(1);
					if (propName === "Color3uint8") propName = "Color3";

					const instList = Classes[ClassID].Instances;
					for (let i = 0; i < instList.length; i++) {
						const instId = instList[i];
						Instances[instId][propName] = Value.values[i];
					}
				}

				break;
			}

			case "PRNT": {
				Payload.byteOffset++; // skip unknown byte

				const assocLength = Payload.getUint32(true);
				const children = ReadReferences(Payload, assocLength);
				const parents = ReadReferences(Payload, assocLength);

				let childId = 0;
				let parentId = 0;

				for (let i = 0; i < assocLength; i++) {
					childId += children[i];
					parentId += parents[i];

					const child = Instances[childId];
					if (parentId < 0) {
						Game[childId] = child;
					} else {
						const parent = Instances[parentId];
						parent.Children.push(child);
					}
				}

				break;
			}
		}
	}

	console.log(
		"Finished decoding file.\nTime elapsed:",
		performance.now() - start,
		"ms"
	);

	return {
		Metadata,
		Game,
	};
}
