import { getAPIDump } from "../utilities.js";
const APIDump = await getAPIDump();
const { Classes, Enums } = APIDump;

if (
	APIDump == null ||
	Classes == null ||
	Enums == null
) throw new Error("Invalid API dump");

/**
 * Gets the enum's name from a property name and class name
 * @param {string} propName Property name
 * @param {string} className Class name
 * @returns
 */
export function getEnumName(propName, className) {
	for (const Class of Classes) {
		if (Class.Name.toLowerCase() === className.toLowerCase()) {
			const { Members, Superclass } = Class;

			for (const Member of Members) {
				if (
					Member.MemberType === "Property" &&
					Member.Name.toLowerCase() === propName.toLowerCase() &&
					Member.ValueType.Category === "Enum"
				) return Member.ValueType.Name;
			};

			if (
				Superclass &&
				Superclass !== "<<<ROOT>>>"
			) return getEnumName(propName, Superclass);
		}
	}
}

/**
 * Gets the enum's name as a string from it's numerical value
 * @param {string} enumName Enum name
 * @param {number} value The numerical value of the enum
 * @returns
 */
export function getEnumValue(enumName, itemValue) {
	for (const Enum of Enums) {
		if (Enum.Name.toLowerCase() === enumName.toLowerCase()) {
			const { Items } = Enum;

			for (const Item of Items) {
				if (Item.Value === itemValue) {
					return Item.Name;
				}
			}
		}
	}
}