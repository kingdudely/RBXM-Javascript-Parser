import ByteEditor from "./ByteEditor.js";
import GetChunkReader from "./ChunkReader.js";
import CreatePropertyValueReader from "./PropertyReader.js"

// NOTE: String sizes are usually fetched with getUint32

const fileSignature = new Uint8Array([
	0x3c, 0x72, 0x6f, 0x62, 0x6c, 0x6f, 0x78, 0x21, // Magic Number (<roblox!)
	0x89, 0xff, 0x0d, 0x0a, 0x1a, 0x0a, // Signature
]);
const fileSignatureLength = fileSignature.length;

export function decode(buffer) {
	const
		Chunks = {},
		Headers = {};

	const fileReader = new ByteEditor(buffer);
	for (let i = 0; i < fileSignatureLength; i++) {
		if (fileReader.getUint8() !== fileSignature[i]) {
			throw new Error("Invalid file signature");
		};
	};

	Headers.Version = fileReader.getUint16(true);
	Headers.ClassCount = fileReader.getInt32(true);
	Headers.InstanceCount = fileReader.getInt32(true);

	fileReader.move(8); // Reserved

	let Processing = true;
	while (Processing) {
		const {
			Signature: chunkSignature,
			Reader: chunkReader
		} = GetChunkReader(fileReader);

		const Chunk = {};
		Chunks[chunkSignature] ??= [];

		switch (chunkSignature) {
			case "META": {
				const metadataAmount = chunkReader.getUint32(true);

				for (let i = 0; i < metadataAmount; i++) {
					const key = chunkReader.readString(chunkReader.getUint32(true));
					const value = chunkReader.readString(chunkReader.getUint32(true));

					Chunk[key] = value;
				};

				break;
			};

			case "SSTR": {
				Chunk.Version = chunkReader.getUint32(true);

				const sharedStringsAmount = chunkReader.getUint32(true);
				const SharedStrings = new Array(sharedStringsAmount);

				for (let i = 0; i < sharedStringsAmount; i++) {
					SharedStrings[i] = {
						Hash: chunkReader.readString(16),
						String: chunkReader.readString(chunkReader.getUint32(true)),
					};
				};

				Chunk.SharedStrings = SharedStrings;
				break;
			};

			case "INST": { // A class; "Part", "Folder", etc.
				const ClassID = chunkReader.getUint32(true);
				const ClassName = chunkReader.readString(chunkReader.getUint32(true));
				const IsService = Boolean(chunkReader.getUint8(true));
				const instanceAmount = chunkReader.getUint32(true);

				const Referents = chunkReader.getInterleavedInt32(instanceAmount);
				for (let i = 1; i < instanceAmount; i++) {
					Referents[i] += Referents[i - 1];
				};

				if (IsService) {
					const ServiceMarkers = new Array(instanceAmount)
					for (let i = 0; i < instanceAmount; i++) {
						ServiceMarkers[i] = chunkReader.getUint8() === 1;
					};

					Chunk.ServiceMarkers = ServiceMarkers;
				};

				Chunk.ClassName = ClassName;
				Chunk.IsService = IsService;
				Chunk.Referents = Referents;

				Chunks[chunkSignature][ClassID] = Chunk;
				continue; // Do not push Chunk to end
			};

			case "PROP": {
				const { INST } = Chunks;
				if (INST == null) {
					throw new Error("Invalid RBXM, missing INST chunk");	
				};

				const ClassID = chunkReader.getUint32(true);
				const Class = INST[ClassID];
				const instanceAmount = Class.Referents.length;

				const propertyName = chunkReader.readString(chunkReader.getUint32(true));
				const dataTypeID = chunkReader.getUint8(true);

				const propertyValues = new Array(instanceAmount);
				const propertyReader = CreatePropertyValueReader(chunkReader, dataTypeID);
				for (let i = 0; i < instanceAmount; i++) {
					propertyValues[i] = propertyReader();
				};

				console.log(propertyValues)

				break;
			};

			case "END\x00": {
				Processing = false;
				break;
			};
		};

		Chunks[chunkSignature].push(Chunk);
	};

	console.log(Chunks)
};