const byteSizes = {
	Int8: 1,
	Uint8: 1,
	Int16: 2,
	Uint16: 2,
	Int32: 4,
	Uint32: 4,
	Float32: 4,
	Float64: 8,
	BigInt64: 8,
	BigUint64: 8,
};

const zigzagDecode = x => (x >> 1) ^ (-(x & 1));

function decodeRobloxFloat(n) {
	const exponent = n >>> 24;
	if (exponent === 0) return 0;

	const floatNum =
		Math.pow(2, exponent - 127) * (1 + ((n >>> 1) & 0x7fffff) / 0x7fffff);

	return n & 1 ? -floatNum : floatNum;
};

export default class ByteEditor extends DataView {
	constructor(...args) {
		super(...args);
		this.byteIndex = 0;
	}

	move(offset) {
		this.byteIndex += offset;
		return this;
	}

	goto(offset) {
		this.byteIndex = offset;
		return this;
	}

	readBytes(length) {
		const result = new Uint8Array(length);

		for (let i = 0; i < length; i++) {
			result[i] = this.getUint8();
		};

		return result;
	}

	readString(length) {
		const bytes = this.readBytes(length);
		return String.fromCharCode(...bytes);
	}


	getInterleavedInt8(length) {
		const result = new Int8Array(this.readBytes(length));

		for (let i = 0; i < length; i++) {
			result[i] = zigzagDecode(result[i]);
		};

		return result;
	}

	getInterleavedUint32(length) {
		const result = new Uint32Array(length);
		const startOffset = this.byteIndex;
		const
			length2 = length * 2,
			length3 = length * 3,
			length4 = length * 4;

		for (let i = 0; i < length; i++) {
			const
				byte0 = super.getUint8(startOffset + i),
				byte1 = super.getUint8(startOffset + ((i + length) % length4)),
				byte2 = super.getUint8(startOffset + ((i + length2) % length4)),
				byte3 = super.getUint8(startOffset + ((i + length3) % length4));

			result[i] = (byte0 << 24) + (byte1 << 16) + (byte2 << 8) + byte3;
		}

		this.move(length4);
		return result;
	}


	getInterleavedInt32(length) {
		const result = new Int32Array(this.getInterleavedUint32(length));

		for (let i = 0; i < length; i++) {
			result[i] = zigzagDecode(result[i]);
		};

		return result;
	}

	getInterleavedFloat32(length) {
		const result = new Float32Array(this.getInterleavedUint32(length));

		for (let i = 0; i < length; i++) {
			result[i] = decodeRobloxFloat(result[i]);
		};

		return result;
	}
}

const
	ByteEditorPrototype = ByteEditor.prototype,
	DataViewPrototype = DataView.prototype;

function DataViewToByteEditorFunction(functionName, byteIncrement) {
	const func = DataViewPrototype[functionName];
	if (typeof func !== "function") {
		throw new Error("Invalid function name");
	};

	return function (...args) {
		const { byteIndex, byteLength } = this;
		if (byteIndex + byteIncrement > byteLength) {
			throw new RangeError(`Attempt to read beyond buffer length: offset ${byteIndex}, size ${byteIncrement}, length ${byteLength}`);
		};

		this.move(byteIncrement);

		return func.call(this, byteIndex, ...args);
	};
};

for (const [name, size] of Object.entries(byteSizes)) {
	const
		getName = "get" + name,
		setName = "set" + name;

	ByteEditorPrototype[getName] = DataViewToByteEditorFunction(getName, size);
	ByteEditorPrototype[setName] = DataViewToByteEditorFunction(setName, size);
}