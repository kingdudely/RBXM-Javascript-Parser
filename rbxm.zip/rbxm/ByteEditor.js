const textDecoder = new TextDecoder("utf-8");
const byteSizes = {
	Int8: 1,
	Uint8: 1,
	Int16: 2,
	Uint16: 2,
	Int32: 4,
	Uint32: 4,
	Float32: 4,
	Float64: 8,
	BigInt64: 8,
	BigUint64: 8,
};

const zigzagDecode = x => (x >> 1) ^ (-(x & 1));
const bigZigzagDecode = x => (x >> 1n) ^ (-(x & 1n)); // BigInt

function decodeRobloxFloat(n) {
	const exponent = n >>> 24;
	if (exponent === 0) return 0;

	const float =
		Math.pow(2, exponent - 127) * (1 + ((n >>> 1) & 0x7fffff) / 0x7fffff);

	return n & 1 ? -float : float;
};

export default class ByteEditor extends DataView {
	constructor(...args) {
		super(...args);
		this.byteIndex = 0;
	}

	move(offset) {
		this.byteIndex += offset;
		return this;
	}

	goto(offset) {
		this.byteIndex = offset;
		return this;
	}

	readBytes(length) {
		const result = new Uint8Array(length);

		for (let i = 0; i < length; i++) {
			result[i] = this.getUint8();
		};

		return result;
	}

	readString(length) {
		const bytes = this.readBytes(length);
		return textDecoder.decode(bytes);
		// return String.fromCharCode(...bytes);
	}

	readBoolean() {
		return Boolean(this.getUint8()); // === 1
	}

	readReferents(amount) {
		const Referents = this.getInterleavedInt32(amount);

		for (let i = 1; i < amount; i++) {
			Referents[i] += Referents[i - 1];
		};

		return Referents;
	}

	getInterleavedInt8(length) {
		const result = new Int8Array(this.readBytes(length));

		for (let i = 0; i < length; i++) {
			result[i] = zigzagDecode(result[i]);
		};

		return result;
	}

	// Bitwise OR/Addition? IDK
	getInterleavedUint32(length) {
		const result = new Uint32Array(length);
		const startOffset = this.byteIndex;
		const
			length2 = length * 2,
			length3 = length * 3,
			length4 = length * 4;

		for (let i = 0; i < length; i++) {
			const
				byte0 = super.getUint8(startOffset + i),
				byte1 = super.getUint8(startOffset + ((i + length) % length4)),
				byte2 = super.getUint8(startOffset + ((i + length2) % length4)),
				byte3 = super.getUint8(startOffset + ((i + length3) % length4));

			result[i] =
				(byte0 << 24) +
				(byte1 << 16) +
				(byte2 << 8) +
				byte3;
		}

		this.move(length4);
		return result;
	}

	/*
	getInterleavedUint32(length) {
		const result = new Uint32Array(length);
		const startOffset = this.byteIndex;
		const length4 = length * 4;

		for (let i = 0; i < length; i++) {
			let value = 0;

			for (let byteIndex = 0; byteIndex < 4; byteIndex++) {
				const offset = startOffset + ((i + length * byteIndex) % length4);
				const byte = super.getUint8(offset);
				value = (value << 8) | byte;
			}

			result[i] = value;
		}

		this.move(length4);
		return result;
	}
	*/


	getInterleavedUint64(length) {
		const result = new BigUint64Array(length);
		const startOffset = this.byteIndex;

		const
			length2 = length * 2,
			length3 = length * 3,
			length4 = length * 4,
			length5 = length * 5,
			length6 = length * 6,
			length7 = length * 7,
			length8 = length * 8;

		for (let i = 0; i < length; i++) {
			const
				byte0 = BigInt(super.getUint8(startOffset + i)),
				byte1 = BigInt(super.getUint8(startOffset + ((i + length) % length8))),
				byte2 = BigInt(super.getUint8(startOffset + ((i + length2) % length8))),
				byte3 = BigInt(super.getUint8(startOffset + ((i + length3) % length8))),
				byte4 = BigInt(super.getUint8(startOffset + ((i + length4) % length8))),
				byte5 = BigInt(super.getUint8(startOffset + ((i + length5) % length8))),
				byte6 = BigInt(super.getUint8(startOffset + ((i + length6) % length8))),
				byte7 = BigInt(super.getUint8(startOffset + ((i + length7) % length8)));

			result[i] =
				(byte0 << 56n) +
				(byte1 << 48n) +
				(byte2 << 40n) +
				(byte3 << 32n) +
				(byte4 << 24n) +
				(byte5 << 16n) +
				(byte6 << 8n) +
				byte7;
		}

		this.move(length8);
		return result;
	}

	/*
	getInterleavedUint64(length) {
		const result = new BigUint64Array(length);
		const startOffset = this.byteIndex;
		const length8 = length * 8;

		for (let i = 0; i < length; i++) {
			let value = 0n;

			for (let byteIndex = 0; byteIndex < 8; byteIndex++) {
				const offset = startOffset + ((i + length * byteIndex) % (length8));
				const byte = BigInt(super.getUint8(offset));
				value = (value << 8n) | byte; // big-endian
			}

			result[i] = value;
		}

		this.move(length8);
		return result;
	}
	*/

	getInterleavedInt32(length) {
		const result = new Int32Array(this.getInterleavedUint32(length));

		for (let i = 0; i < length; i++) {
			result[i] = zigzagDecode(result[i]);
		};

		return result;
	}

	getInterleavedInt64(length) {
		const result = new BigInt64Array(this.getInterleavedUint64(length));

		for (let i = 0; i < length; i++) {
			result[i] = bigZigzagDecode(result[i]);
		};

		return result;
	}

	getInterleavedFloat32(length) {
		const result = new Float32Array(this.getInterleavedUint32(length));

		for (let i = 0; i < length; i++) {
			result[i] = decodeRobloxFloat(result[i]);
		};

		return result;
	}
}

const
	ByteEditorPrototype = ByteEditor.prototype,
	DataViewPrototype = DataView.prototype;

function DataViewToByteEditorFunction(functionName, byteIncrement) {
	const func = DataViewPrototype[functionName];
	if (typeof func !== "function") {
		throw new Error("Invalid function name");
	};

	return function (...args) {
		const { byteIndex, byteLength } = this;
		if (byteIndex + byteIncrement > byteLength) {
			throw new RangeError(`Attempt to read beyond buffer length: offset ${byteIndex}, size ${byteIncrement}, length ${byteLength}`);
		};

		this.move(byteIncrement);

		return func.call(this, byteIndex, ...args);
	};
};

for (const [name, size] of Object.entries(byteSizes)) {
	const
		getName = "get" + name,
		setName = "set" + name;

	ByteEditorPrototype[getName] = DataViewToByteEditorFunction(getName, size);
	ByteEditorPrototype[setName] = DataViewToByteEditorFunction(setName, size);
}