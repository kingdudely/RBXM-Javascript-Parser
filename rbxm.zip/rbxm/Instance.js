import Enums from "./Enums.js";
import { GetAllClasses, GetAllMembers } from "./ApiUtilities.js";

function IsA(ClassName) {
	const
		Classes = GetAllClasses(this.ClassName), // InheritedClasses
		ClassAmount = Classes.length;

	for (let i = 0; i < ClassAmount; i++) {
		const Class = Classes[i];

		if (Class.Name === ClassName) {
			return true;
		};
	};

	return false;
};

const Defaults = {
	IsA, isA: IsA,
};

const Instance = {};
export default {
	new(ClassName) {
		const Instance = {
			ClassName,
			Children: [],
		};

		Object.defineProperty(Instance, Symbol.toStringTag, {
			value: "Instance",
			configurable: false,
			writable: false,
			enumerable: false 
		});

		const
			Members = GetAllMembers(ClassName),
			MemberAmount = Members?.length;

		for (let i = 0; i < MemberAmount; i++) {
			const { Name: MemberName, Default, MemberType, ValueType } = Members[i];
			let MemberValue = Default ?? null;

			if (MemberType !== "Property" || Default === "__api_dump_class_not_creatable__") {
				MemberValue = Defaults[MemberName] ?? null;
			};

			if (MemberType === "Property") {
				if (ValueType?.Category === "Enum") {
					const
						Enum = Enums[ValueType.Name],
						Item = Enum?.FromName(MemberValue);

					if (Item != null) {
						MemberValue = Item;
					};
				};
			}

			Instance[MemberName] ??= MemberValue;
		};

		return Instance;
	},
};