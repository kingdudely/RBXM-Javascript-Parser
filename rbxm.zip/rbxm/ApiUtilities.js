import APIDump from "./ApiDump.js";
const { Classes, Enums } = APIDump;

/*
if (
	APIDump == null ||
	Classes == null ||
	Enums == null
) throw new Error("Invalid API dump");
*/

export function GetAllClasses(ClassName) {
	const AllClasses = [];
	const ClassAmount = Classes?.length;

	for (let i = 0; i < ClassAmount; i++) {
		const Class = Classes[i];
		const { Name: className, Superclass } = Class;

		if (className === ClassName) {
			AllClasses.push(Class);

			if (
				typeof Superclass === "string" &&
				Superclass !== "<<<ROOT>>>"
			) AllClasses.push(...GetAllClasses(Superclass));

			break;
		};
	};

	return AllClasses;
}

export function GetAllMembers(ClassName) {
	const AllMembers = [];
	const
		AllClasses = GetAllClasses(ClassName),
		AllClassAmount = AllClasses.length;

	for (let i = 0; i < AllClassAmount; i++) {
		const { Members } = AllClasses[i];

		if (Array.isArray(Members)) {
			AllMembers.push(...Members);
		}
	}

	return AllMembers;
}

export function GetEnumNameFromClassProperty(ClassName, PropertyName) {
	const
		Members = GetAllMembers(ClassName),
		MemberAmount = Members.length;

	for (let i = 0; i < MemberAmount; i++) {
		const {
			Name: MemberName,
			MemberType,
			ValueType,
		} = Members[i];

		if (
			MemberType === "Property" &&
			MemberName?.toLowerCase() === PropertyName.toLowerCase() &&
			ValueType?.Category === "Enum"
		) return ValueType?.Name;
	}

	return null;
}

/*
export function GetItemNameFromValue(EnumName, ItemValue) {
	// if (!Array.isArray(Enums)) return null;
	const EnumAmount = Enums?.length;

	for (let a = 0; a < EnumAmount; a++) {
		const Enum = Enums[a];

		if (Enum.Name.toLowerCase() === EnumName.toLowerCase()) {
			const { Items } = Enum;
			const ItemAmount = Items.length;

			for (let b = 0; b < ItemAmount; b++) {
				const Item = Items[b];

				if (Item.Value === ItemValue) {
					return Item.Name;
				};
			};
		};
	};

	return null;
};
*/