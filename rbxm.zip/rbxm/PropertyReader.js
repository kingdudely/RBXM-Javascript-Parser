// Make simpler, readable, optimized, scalable way of reading strings, boolean, etc.
import Enums from "./Enums.js";
import { GetAllMembers, GetEnumNameFromClassProperty } from "./ApiUtilities.js";
import { DataTypes, BrickColors, CFrameOrientations, SecurityCapabilities } from "./Constants.js";

const radiansToDegrees = 180 / Math.PI;
function rotationMatrixToEulerAngles(Matrix) {
	const [R00, R01, R02, R10, R11, R12, R20, R21, R22] = Matrix;

	const
		X = Math.atan2(R21, R22),
		Y = Math.atan2(-R20, Math.hypot(R21, R22)),
		Z = Math.atan2(R10, R00);

	return [X * radiansToDegrees, Y * radiansToDegrees, Z * radiansToDegrees];
};

function referentsToObjects(Referents, References) {
	const ReferentAmount = Referents.length;
	const Objects = new Array(ReferentAmount);

	for (let i = 0; i < ReferentAmount; i++) {
		const Referent = Referents[i];
		const Object = References[Referent];

		if (Object != null) {
			Objects[i] = Object;
		};
	};

	return Objects;
};

export default function GetPropertyValues(Reader, { PropertyName, PropertyAmount, ClassName, Objects }) {
	let
		DataTypeID = Reader.getUint8(true),
		DataType = DataTypes[DataTypeID];

	if (DataType == null) {
		console.warn("Unknown data type, ID " + DataTypeID);
		return null;
	};

	const IsOptionalCFrame = DataType === "OptionalCoordinateFrame";
	if (IsOptionalCFrame) {
		DataTypeID = Reader.getUint8(true);
		DataType = DataTypes[DataTypeID];

		if (DataType !== "CFrame") {
			console.error("Invalid OptionalCoordinateFrame");
			return null;
		};
	};

	let
		getNextValue = () => null,
		ArrayType = Array;

	switch (DataType) {
		case "String": {
			getNextValue = () => Reader.readString(Reader.getUint32(true));
			break;
		};

		case "Bool": {
			getNextValue = () => Reader.readBoolean();
			break;
		};

		case "Int32": return Reader.getInterleavedInt32(PropertyAmount);

		case "Float32": return Reader.getInterleavedFloat32(PropertyAmount);

		case "Float64": {
			ArrayType = Float64Array;
			getNextValue = () => Reader.getFloat64(true);
			break;
		};

		case "UDim": {
			const Scales = Reader.getInterleavedFloat32(PropertyAmount);
			const Offsets = Reader.getInterleavedInt32(PropertyAmount);

			getNextValue = i => ({
				Scale: Scales[i],
				Offset: Offsets[i],
			});

			break;
		}
		case "UDim2": {
			const
				XScales = Reader.getInterleavedFloat32(PropertyAmount),
				YScales = Reader.getInterleavedFloat32(PropertyAmount);
				
			const
				XOffsets = Reader.getInterleavedInt32(PropertyAmount),
				YOffsets = Reader.getInterleavedInt32(PropertyAmount);

			getNextValue = i => ({
				X: {
					Scale: XScales[i],
					Offset: XOffsets[i],
				},

				Y: {
					Scale: YScales[i],
					Offset: YOffsets[i],
				},
			});

			break;
		};

		case "Ray": {
			getNextValue = () => ({
				Origin: {
					X: Reader.getFloat32(true),
					Y: Reader.getFloat32(true),
					Z: Reader.getFloat32(true),
				},

				Direction: {
					X: Reader.getFloat32(true),
					Y: Reader.getFloat32(true),
					Z: Reader.getFloat32(true),
				}
			});

			break;
		};

		case "Faces": {
			getNextValue = () => {
				const Faces = Reader.getUint8();

				return {
					Right: Boolean(Faces & 1),
					Top: Boolean(Faces & 2),
					Back: Boolean(Faces & 4),
					Left: Boolean(Faces & 8),
					Bottom: Boolean(Faces & 16),
					Front: Boolean(Faces & 32),
				};
			};
			
			break;
		};

		case "Axes": {
			getNextValue = () => {
				const Axes = Reader.getUint8();

				return {
					X: Boolean(Axes & 1),
					Y: Boolean(Axes & 2),
					Z: Boolean(Axes & 4),
				};
			};

			break;
		};

		case "BrickColor": {
			const BrickColor = Reader.getInterleavedUint32(PropertyAmount);

			getNextValue = i => {
				const BrickColorID = BrickColor[i];
				const [Name, [R, G, B]] = BrickColors[BrickColorID] ?? ["Really black", [0, 0, 0]];
				/*
				let [Name, Color] = BrickColors[BrickColorID];
				Name ??= "Really black";
				Color ??= [0, 0, 0];

				const [R, G, B] = Color;
				*/

				return {
					Name,
					Color: { R, G, B },
					Number: BrickColorID,
				};
			}

			break;
		};

		case "Color3": {
			const
				R = Reader.getInterleavedFloat32(PropertyAmount),
				G = Reader.getInterleavedFloat32(PropertyAmount),
				B = Reader.getInterleavedFloat32(PropertyAmount);

			getNextValue = i => ({
				R: R[i],
				G: G[i],
				B: B[i],
			});

			break;
		};

		case "Vector2": {
			const
				X = Reader.getInterleavedFloat32(PropertyAmount),
				Y = Reader.getInterleavedFloat32(PropertyAmount);

			getNextValue = i => ({
				X: X[i],
				Y: Y[i],
			});

			break;
		};

		case "Vector3": {
			const
				X = Reader.getInterleavedFloat32(PropertyAmount),
				Y = Reader.getInterleavedFloat32(PropertyAmount),
				Z = Reader.getInterleavedFloat32(PropertyAmount);

			getNextValue = i => ({
				X: X[i],
				Y: Y[i],
				Z: Z[i],
			});

			break;
		};

		case "Vector2int16": {
			getNextValue = () => ({
				X: Reader.getInt16(true),
				Y: Reader.getInt16(true),
			});

			break;
		}

		case "CFrame": {
			// b < 9 because there are 9 orientations
			// b + 3 because we are skipping the X, Y, Z
			const CFrames = new Array(PropertyAmount); // CFrames/RotationMatrixes

			for (let a = 0; a < PropertyAmount; a++) {
				const CFrame = new Float32Array(12); // X, Y, Z, R00, R01, R02, R10, R11, R12, R20, R21, R22

				const
					RotationID = Reader.getUint8(),
					Rotation = CFrameOrientations[RotationID];

				if (Array.isArray(Rotation)) { // RotationID !== 0
					for (let b = 0; b < 9; b++) {
						CFrame[b + 3] = Rotation[b];
					};
					// CFrame = [0, 0, 0, ...CFrameRotations[RotationID]];
				} else {
					for (let b = 0; b < 9; b++) {
						CFrame[b + 3] = Reader.getFloat32(true);
					};
				}

				CFrames[a] = CFrame;
			}

			const
				VectorX = Reader.getInterleavedFloat32(PropertyAmount),
				VectorY = Reader.getInterleavedFloat32(PropertyAmount),
				VectorZ = Reader.getInterleavedFloat32(PropertyAmount);

			for (let i = 0; i < PropertyAmount; i++) {
				if (IsOptionalCFrame) {
					const CFrameExists = Reader.readBoolean();
					if (!CFrameExists) {
						// CFrame[i] = null;
						continue;
					};
				};

				const CFrame = CFrames[i];

				const [EulerX, EulerY, EulerZ] = rotationMatrixToEulerAngles(CFrame.slice(3));
				CFrame[0] = VectorX[i];
				CFrame[1] = VectorY[i];
				CFrame[2] = VectorZ[i];

				CFrames[i] = {
					Position: {
						X: VectorX[i],
						Y: VectorY[i],
						Z: VectorZ[i],
					},

					Orientation: {
						X: EulerX,
						Y: EulerY,
						Z: EulerZ,
					},

					Components: CFrame,
				};
			};

			return CFrames;
		}

		case "CFrameQuat": return null; // ?

		case "Enum": { // Token
			const EnumValues = Array.from(Reader.getInterleavedUint32(PropertyAmount));

			for (let i = 0; i < PropertyAmount; i++) {
				const
					EnumName = GetEnumNameFromClassProperty(ClassName, PropertyName),
					Enum = Enums[EnumName];

				if (Enum != null) {
					EnumValues[i] = Enum.FromValue(EnumValues[i]);
				};
			};

			return EnumValues;
		};

		case "Referent": return referentsToObjects(Reader.readReferents(PropertyAmount), Objects);

		case "Vector3int16": {
			getNextValue = () => ({
				X: Reader.getUint16(true),
				Y: Reader.getUint16(true),
				Z: Reader.getUint16(true),
			});

			break;
		};

		case "NumberSequence": {
			getNextValue = () => {
				const
					SequenceAmount = Reader.getUint32(true),
					Sequence = new Array(SequenceAmount);

				for (let i = 0; i < SequenceAmount; i++) {
					Sequence[i] = {
						Time: Reader.getFloat32(true),
						Value: Reader.getFloat32(true),
						Envelope: Reader.getFloat32(true),
					};
				};

				return Sequence;
			};

			break;
		};

		case "ColorSequence": {
			getNextValue = () => {
				const
					SequenceAmount = Reader.getUint32(true),
					Sequence = new Array(SequenceAmount);

				for (let i = 0; i < SequenceAmount; i++) {
					Sequence[i] = {
						Time: Reader.getFloat32(true),

						Value: {
							R: Reader.getFloat32(true),
							G: Reader.getFloat32(true),
							B: Reader.getFloat32(true),
						},

						Envelope: Reader.getFloat32(true),
					};
				};

				return Sequence;
			};

			break;
		};

		case "NumberRange": {
			getNextValue = () => ({
				Min: Reader.getFloat32(true),
				Max: Reader.getFloat32(true),
			});

			break;
		}

		case "Rect": {
			const
				MinX = Reader.getInterleavedFloat32(PropertyAmount),
				MinY = Reader.getInterleavedFloat32(PropertyAmount);

			const
				MaxX = Reader.getInterleavedFloat32(PropertyAmount),
				MaxY = Reader.getInterleavedFloat32(PropertyAmount);

			getNextValue = i => ({
				Min: {
					X: MinX[i],
					Y: MinY[i],
				},

				Max: {
					X: MaxX[i],
					Y: MaxY[i],
				},
			});

			break;
		};

		case "PhysicalProperties": {
			getNextValue = () => {
				const CustomPhysics = Reader.readBoolean();

				if (CustomPhysics) {
					return {
						Density: Reader.getFloat32(true),
						Friction: Reader.getFloat32(true),
						Elasticity: Reader.getFloat32(true),
						FrictionWeight: Reader.getFloat32(true),
						ElasticityWeight: Reader.getFloat32(true),
					};
				};
			};

			break;
		};

		case "Color3uint8": {
			const
				R = Reader.readBytes(PropertyAmount),
				G = Reader.readBytes(PropertyAmount),
				B = Reader.readBytes(PropertyAmount);

			getNextValue = i => ({
				R: R[i] / 255,
				G: G[i] / 255,
				B: B[i] / 255,
			});

			break;
		};

		case "Int64": return Reader.getInterleavedInt64(PropertyAmount);

		case "SharedString": return Reader.getInterleavedUint32(PropertyAmount);

		case "Bytecode": { // Identical to String
			getNextValue = () => Reader.readString(Reader.getUint32(true));
			break;
		};

		// OptionalCoordinateFrame implemented in CFrame

		case "UniqueId": {
			const
				Index = Reader.getInterleavedUint32(PropertyAmount),
				Time = Reader.getInterleavedUint32(PropertyAmount),
				Random = Reader.getInterleavedInt64(PropertyAmount);

			getNextValue = i => ({
				Index: Index[i],
				Time: Time[i],
				Random: Random[i],
			});

			break;
		};

		case "Font": {
			getNextValue = () => ({
				Family: Reader.readString(Reader.getUint32(true)),
				Weight: Reader.getUint16(true),
				Style: Reader.getUint8(),
				CachedFaceId: Reader.readString(Reader.getUint32(true)),
			});

			break;
		};

		case "SecurityCapabilities": {
			const CapabilityAmount = SecurityCapabilities.length;

			getNextValue = () => {
				const Capabilities = {};

				for (let i = 0; i < CapabilityAmount; i++) {
					Capabilities[SecurityCapabilities[i]] = Reader.readBoolean();
				};

				return Capabilities;
			};

			break;
		}


		case "Content": {
			const SourceTypes = new Uint8Array(PropertyAmount);
			for (let i = 0; i < PropertyAmount; i++) {
				SourceTypes[i] = Reader.getUint8(); // getEnumItemNameFromValue("ContentSourceType", Reader.getUint8())
			}

			const
				URIAmount = Reader.getUint32(true),
				URIs = new Array(URIAmount);

			for (let i = 0; i < URIAmount; i++) {
				URIs[i] = Reader.readString(Reader.getUint32(true));
			}

			const
				ReferentAmount = Reader.getUint32(true),
				Objects = referentsToObjects(Reader.readReferents(ReferentAmount), Objects);

			const ExternalReferentAmount = Reader.getUint32(true); // Reference?
			Reader.readReferents(ExternalReferentAmount);

			let
				URIIndex = 0,
				ObjectIndex = 0;

			getNextValue = i => {
				switch (SourceTypes[i]) {
					case 0: // None
						return {
							Type: "None",
							Value: null,
						};

					case 1: // Uri
						return {
							Type: "Uri",
							Value: URIs[URIIndex++] ?? null,
						};

					case 2: // Object
						return {
							Type: "Object",
							Value: Objects[ObjectIndex++] ?? null, // Referent
						};

					default:
						console.warn(`Invalid Content data type, SourceType ${SourceTypes[i]}`);
						return null;
				}
			};

			break;
		}

		// default: return;
	};

	const Values = new ArrayType(PropertyAmount);

	for (let i = 0; i < PropertyAmount; i++) {
		Values[i] = getNextValue(i);
	};

	return Values;
};