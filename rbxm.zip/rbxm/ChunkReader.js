// Chunk:
// Signature: [4]getUint8 - Type of chunk and structure of data
// CompressedLength: getUint32 - Length of the data
// UncompressedLength: getUint32 - Length of the data after decompression
// Reserved: [4]getUint8 - Reserved for future use
// Data: []getUint8 - The data
// Chunks are compressed using LZ4
// If the chunk is not compressed, CompressedLength == 0 and UncompressedLength == the length of the data

import LZ4BlockJS from "./lz4.js";
import ByteEditor from "./ByteEditor.js";
import * as ZSTD from "./zstd.js"; // 28 b5 2f fd

export default function GetChunkReader(Reader) {
	const chunkSignature = Reader.readString(4);

	const compressedLength = Reader.getUint32(true);
	const uncompressedLength = Reader.getUint32(true);
	const dataLength = compressedLength || uncompressedLength;

	Reader.move(4); // Skip Reserved

	const chunkData = Reader.readBytes(dataLength);

	let decompressedData;
	if (compressedLength > 0) {
		try {
			decompressedData = ZSTD.decompress(chunkData);
		} catch {
			decompressedData = LZ4BlockJS.prototype.decodeBlock(chunkData, 0, uncompressedLength);
		}
	} else {
		decompressedData = chunkData;
	}

	const chunkReader = new ByteEditor(decompressedData.buffer);

	return {
		Signature: chunkSignature,
		Reader: chunkReader,
	};
}