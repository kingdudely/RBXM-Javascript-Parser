// String:
// Length: uint32 - Length of the string
// Bytes: []uint8 - The string
// https://github.com/MrSprinkleToes/rbxBinaryParser/blob/master/src/binaryTypeReader.js
import ByteReader from "./ByteReader.js";
import { BrickColorIDs, RotationIDs, TypeIDs } from "./ids.js";
import { getEnumName, getEnumValue } from "./EnumFetcher.js";
import { rotationMatrixToEulerAngles } from "../modules/utilities.js";

const textDecoder = new TextDecoder();

// References: []zint32b~4
// Difference-encoded array of zigzag-encoded interleaved integers
// Before encoding to bytes, values in the References array are difference-encoded
// such that the current value is added to the previous value to get the actual value.

function ReadString(Reader) {
	const length = Reader.getUint32(true);
	const bytes = new Uint8Array(Reader.buffer, Reader.byteOffset, length);
	const string = textDecoder.decode(bytes);
	
	return string;
}

function ReadReferences(Reader, Length) {
	return Reader.getInterleavedInt32(Length);
}

function ReadPropertyValue(Reader, InstanceCount, ClassName, PropertyName) {
	const TypeID = Reader.getUint8();
	const Type = TypeIDs[TypeID];

	let Values = new Array(InstanceCount);

	switch (Type) {
		case "String": {
			for (let i = 0; i < InstanceCount; i++) {
				const [String] = ReadString(Reader);
				Values[i] = String;
			};

			break;
		}
		case "Bool": {
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = Reader.getUint8() === 1;
			};

			break;
		}
		case "Int": {
			// is encoded as zint32b~4
			Values = Reader.getInterleavedInt32(InstanceCount);
			break;
		}
		case "Float": {
			// is encoded as rfloat32b~4
			Values = Reader.getInterleavedFloat(InstanceCount);
			break;
		}
		case "Double": {
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = Reader.getFloat64(true);
			};

			break;
		}
		case "UDim": {
			const scale = Reader.getInterleavedFloat(InstanceCount);
			const offset = Reader.getInterleavedInt32(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = { Scale: scale[i], Offset: offset[i] };
			};

			break;
		}
		case "UDim2": {
			const scaleX = Reader.getInterleavedFloat(InstanceCount);
			const scaleY = Reader.getInterleavedFloat(InstanceCount);
			const offsetX = Reader.getInterleavedInt32(InstanceCount);
			const offsetY = Reader.getInterleavedInt32(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = {
					X: { Scale: scaleX[i], Offset: offsetX[i] },
					Y: { Scale: scaleY[i], Offset: offsetY[i] },
				};
			};

			break;
		};

		case "Ray": {
			for (let i = 0; i < InstanceCount; i++) {
				const origin = {
					X: Reader.getFloat32(true),
					Y: Reader.getFloat32(true),
					Z: Reader.getFloat32(true),
				};
				const direction = {
					X: Reader.getFloat32(true),
					Y: Reader.getFloat32(true),
					Z: Reader.getFloat32(true),
				};
				Values[i] = { Origin: origin, Direction: direction };
			}

			break;
		}

		case "Faces": {
			for (let i = 0; i < InstanceCount; i++) {
				const faces = Reader.getUint8();
	
				Values[i] = {
					Right: !!(faces & 1),
					Top: !!(faces & 2),
					Back: !!(faces & 4),
					Left: !!(faces & 8),
					Bottom: !!(faces & 16),
					Front: !!(faces & 32),
				};
			}

			break;
		}

		case "Axes": {
			for (let i = 0; i < InstanceCount; i++) {
				const axes = Reader.getUint8();
	
				Values[i] = {
					X: !!(axes & 1),
					Y: !!(axes & 2),
					Z: !!(axes & 4),
				};
			}

			break;
		}

		case "BrickColor": {
			const BrickColor = Reader.getInterleavedUint32(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				let [Name, Color] = BrickColorIDs[BrickColor[i]];
				Name ??= "Really black";
				Color ??= [0, 0, 0];
				const [R, G, B] = Color;
	
				Values[i] = {
					Name,
					Color: { R, G, B },
					Number: BrickColor[i],
				};
			}

			break;
		}

		case "Color3": {
			const R = Reader.getInterleavedFloat(InstanceCount);
			const G = Reader.getInterleavedFloat(InstanceCount);
			const B = Reader.getInterleavedFloat(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = { R: R[i], G: G[i], B: B[i] };
			}

			break;
		}

		case "Vector2": {
			const Y = Reader.getInterleavedFloat(InstanceCount);
			const X = Reader.getInterleavedFloat(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = { X: X[i], Y: Y[i] };
			}

			break;
		}

		case "Vector3": {
			const X = Reader.getInterleavedFloat(InstanceCount);
			const Y = Reader.getInterleavedFloat(InstanceCount);
			const Z = Reader.getInterleavedFloat(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = { X: X[i], Y: Y[i], Z: Z[i] };
			}

			break;
		}

		case "Vector2int16": {
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = {
					X: Reader.getInt16(true),
					Y: Reader.getInt16(true),
				};
			}

			break;
		}

		case "CFrame": {
			const CFrames = new Array(InstanceCount);
	
			for (let a = 0; a < InstanceCount; a++) {
				let CFrame = [0, 0, 0];
				const RotationID = Reader.getUint8();
	
				if (RotationID !== 0) {
					CFrame = [0, 0, 0, ...RotationIDs[RotationID]];
				} else {
					for (let b = 0; b < 9; b++) {
						CFrame[b + 3] = Reader.getFloat32(true);
					}
				}
	
				CFrames[a] = CFrame;
			}
	
			const VectorX = Reader.getInterleavedFloat(InstanceCount);
			const VectorY = Reader.getInterleavedFloat(InstanceCount);
			const VectorZ = Reader.getInterleavedFloat(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				const Components = CFrames[i];
	
				const [EulerX, EulerY, EulerZ] = rotationMatrixToEulerAngles(Components.slice(3));
				Components[0] = VectorX[i];
				Components[1] = VectorY[i];
				Components[2] = VectorZ[i];
	
				Values[i] = {
					Position: {
						X: VectorX[i],
						Y: VectorY[i],
						Z: VectorZ[i],
					},
	
					Orientation: {
						X: EulerX,
						Y: EulerY,
						Z: EulerZ,
					},
	
					Components,
				};
			};

			break;
		}

		case "CFrameQuat": {
			// not used
			break;
		}

		case "Enum": { // Token
			let enumValues = Reader.getInterleavedUint32(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				const enumName = getEnumName(PropertyName, ClassName);
	
				if (enumName) {
					const enumValue = getEnumValue(enumName, enumValues[i]);
					enumValues[i] = enumValue;
				}
			}
	
			Values = enumValues;

			break;
		}

		case "Reference": {
			// TODO: implement
			break;
		}

		case "Vector3uint16": {
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = {
					X: Reader.getUint16(true),
					Y: Reader.getUint16(true),
					Z: Reader.getUint16(true),
				};
			}

			break;
		};

		case "NumberSequence": {
			for (let a = 0; a < InstanceCount; a++) {
				const length = Reader.getUint32(true);
				Values[a] = [];
	
				for (let b = 0; b < length; b++) {
					const time = Reader.getFloat32(true);
					const value = Reader.getFloat32(true);
					const envelope = Reader.getFloat32(true);
					Values[a].push({
						Time: time,
						Value: value,
						Envelope: envelope,
					});
				}
			};

			break;
		};

		case "ColorSequence": {
			// TODO: implement
			break;
		};

		case "NumberRange": {
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = {
					Min: Reader.getFloat32(true),
					Max: Reader.getFloat32(true),
				};
			};

			break;
		}

		case "Rect": {
			const minX = Reader.getInterleavedFloat(InstanceCount);
			const minY = Reader.getInterleavedFloat(InstanceCount);
			const maxX = Reader.getInterleavedFloat(InstanceCount);
			const maxY = Reader.getInterleavedFloat(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = {
					Min: {
						X: minX[i],
						Y: minY[i],
					},
					Max: {
						X: maxX[i],
						Y: maxY[i],
					},
				};
			};

			break;
		};

		case "PhysicalProperties": {
			for (let i = 0; i < InstanceCount; i++) {
				const hasCustomPhysics = Reader.getUint8() === 1;
	
				if (hasCustomPhysics) {
					Values[i] = {
						Density: Reader.getFloat32(true),
						Friction: Reader.getFloat32(true),
						Elasticity: Reader.getFloat32(true),
						FrictionWeight: Reader.getFloat32(true),
						ElasticityWeight: Reader.getFloat32(true),
					};
				}
			};

			break;
		};

		case "Color3uint8": {
			const R = Reader.getInterleavedUint8(InstanceCount);
			const G = Reader.getInterleavedUint8(InstanceCount);
			const B = Reader.getInterleavedUint8(InstanceCount);
	
			for (let i = 0; i < InstanceCount; i++) {
				Values[i] = {
					R: R[i] / 255,
					G: G[i] / 255,
					B: B[i] / 255,
				};
			}
			break;
		};

		default: {
			Values = null;
		};
	}

	return {
		Type,
		Values,
	};
}

export { ReadString, ReadReferences, ReadPropertyValue };
