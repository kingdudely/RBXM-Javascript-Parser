async function getVersionInfo() {
	return (await fetch("https://clientsettings.roblox.com/v2/client-version/WindowsStudio64/")).json();
};

async function getAPIDump() {
	const version = (await getVersionInfo())?.clientVersionUpload;
	if (version == null) {
		alert("Something has gone wrong. Please try again later.");
		throw new Error("Fetching version failed!");
	};

	return (await fetch(`https://setup.rbxcdn.com/${version}-Full-API-Dump.json`)).json();
};

/* Mini
async function getAPIDump() {
	return (await fetch("https://raw.githubusercontent.com/MaximumADHD/Roblox-Client-Tracker/roblox/Mini-API-Dump.json")).json();
};
*/

export default (window.navigator.onLine ? await getAPIDump() : {});