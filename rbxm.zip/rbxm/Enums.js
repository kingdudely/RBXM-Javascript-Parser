import ApiDump from "./ApiDump.js";
const
    { Enums: EnumDump } = ApiDump,
    EnumAmount = EnumDump?.length;

const Enums = {};

function FromValue(Value) { // Enum,
    const Items = Object.values(this);
    const ItemAmount = Items?.length;

    for (let i = 0; i < ItemAmount; i++) {
        const Item = Items[i];
        if (Item?.Value === Value) {
            return Item;
        };
    };

    return null;
};

function FromName(Name) { // Enum,
    const Items = Object.values(this);
    const ItemAmount = Items?.length;

    for (let i = 0; i < ItemAmount; i++) {
        const Item = Items[i];
        if (Item?.Name === Name) {
            return Item;
        };
    };

    return null;
};

for (let a = 0; a < EnumAmount; a++) {
    const { Name: EnumName, Items } = EnumDump[a];
    const ItemAmount = Items?.length;
    if (EnumName == null || Items == null) continue;

    const Enum = Enums[EnumName] ??= {
        FromName,
        FromValue,
    };

    for (let b = 0; b < ItemAmount; b++) {
        const
            Item = Items[b],
            ItemName = Item.Name;
        if (Item == null) continue;

        Item.EnumType = Enum;

        Object.defineProperty(Item, Symbol.toStringTag, {
            value: `Enum.${EnumName}.${ItemName}`, // "EnumItem"
            configurable: false,
            writable: false,
            enumerable: false 
        });

        Object.freeze(Item);

        Enum[ItemName] = Item;
    };

    Object.defineProperty(Enum, Symbol.toStringTag, {
        value: `Enum.${EnumName}`,
        configurable: false,
        writable: false,
        enumerable: false 
    });

    Object.freeze(Enum);
};

export default Enums;