import ByteEditor from "./ByteEditor.js";
import GetChunkReader from "./ChunkReader.js";
import GetPropertyValues from "./PropertyReader.js";
import Instance from "./Instance.js";

// NOTE: String sizes are usually fetched with getUint32

const FileSignature = new Uint8Array([
	0x3c, 0x72, 0x6f, 0x62, 0x6c, 0x6f, 0x78, 0x21, // Magic Number (<roblox!)
	0x89, 0xff, 0x0d, 0x0a, 0x1a, 0x0a, // Signature
]);
const FileSignatureLength = FileSignature.length;

export function decode(buffer) {
	const
		Headers = {},
		Chunks = {},
		Game = Instance.new("DataModel"),
		Instances = {
			[-1]: Game,
		};

	const FileReader = new ByteEditor(buffer);
	for (let i = 0; i < FileSignatureLength; i++) {
		if (FileReader.getUint8() !== FileSignature[i]) {
			throw new Error("Invalid file signature");
		};
	};

	Headers.Version = FileReader.getUint16(true);
	Headers.ClassCount = FileReader.getInt32(true);
	Headers.InstanceCount = FileReader.getInt32(true);

	FileReader.move(8); // Reserved

	let Processing = true;
	while (Processing) {
		const {
			Signature: ChunkSignature,
			Reader: ChunkReader
		} = GetChunkReader(FileReader);

		const Chunk = {};
		Chunks[ChunkSignature] ??= [];

		switch (ChunkSignature) {
			case "META": {
				const MetadataAmount = ChunkReader.getUint32(true);

				for (let i = 0; i < MetadataAmount; i++) {
					const Key = ChunkReader.readString(ChunkReader.getUint32(true));
					const Value = ChunkReader.readString(ChunkReader.getUint32(true));

					Chunk[Key] = Value;
				};

				break;
			};

			case "SSTR": {
				Chunk.Version = ChunkReader.getUint32(true);

				const SharedStringAmount = ChunkReader.getUint32(true);
				const SharedStrings = new Array(SharedStringAmount);

				for (let i = 0; i < SharedStringAmount; i++) {
					SharedStrings[i] = {
						Hash: ChunkReader.readString(16),
						String: ChunkReader.readString(ChunkReader.getUint32(true)),
					};
				};

				Chunk.SharedStrings = SharedStrings;
				break;
			};

			case "INST": { // A class; "Part", "Folder", etc.
				const { INST } = Chunks; // Chunks[ChunkSignature]

				const
					ClassID = ChunkReader.getUint32(true),
					ClassName = ChunkReader.readString(ChunkReader.getUint32(true));

				const IsService = ChunkReader.readBoolean();

				const InstanceAmount = ChunkReader.getUint32(true);
				const Referents = ChunkReader.readReferents(InstanceAmount);

				if (IsService) {
					const ServiceMarkers = new Array(InstanceAmount);
					for (let i = 0; i < InstanceAmount; i++) {
						ServiceMarkers[i] = ChunkReader.getUint8() === 1;
					};

					Chunk.ServiceMarkers = ServiceMarkers;
				};

				// Game
				for (let i = 0; i < InstanceAmount; i++) {
					const Referent = Referents[i];
					Instances[Referent] = Instance.new(ClassName);
				}
				//

				Chunk.ClassName = ClassName;
				Chunk.Referents = Referents;
				INST[ClassID] = Chunk;
				continue; // Do not push Chunk to end
			};

			case "PROP": {
				const { PROP, INST } = Chunks;
				if (INST == null) {
					console.warn("Missing INST chunk");
					continue;
				};

				const
					ClassID = ChunkReader.getUint32(true),
					Class = INST[ClassID];
				const { Referents, ClassName } = Class;

				const InstanceAmount = Referents.length;

				const
					PropertyName = ChunkReader.readString(ChunkReader.getUint32(true)),
					PropertyValues = GetPropertyValues(ChunkReader, {
						PropertyAmount: InstanceAmount,
						Objects: Instances,
						ClassName,
						PropertyName,
					});

				const ClassProperties = PROP[ClassID] ??= {};

				for (let i = 0; i < InstanceAmount; i++) {
					const PropertyValue = PropertyValues[i];

					const
						Referent = Referents[i],
						ReferentProperties = ClassProperties[Referent] ??= {};

					ReferentProperties[PropertyName] = PropertyValue;

					// Game
					const Instance = Instances[Referent];
					if (Instance) {
						Instance[PropertyName] = PropertyValue;
					}
					//
				};

				continue;
			};

			case "PRNT": {
				Chunk.Version = ChunkReader.getUint8();
				const InstanceAmount = ChunkReader.getUint32(true);

				const ChildReferents = ChunkReader.readReferents(InstanceAmount);
				const ParentReferents = ChunkReader.readReferents(InstanceAmount);

				Chunk.Hierarchy = {};
				for (let i = 0; i < InstanceAmount; i++) {
					const
						ChildReferent = ChildReferents[i],
						ParentReferent = ParentReferents[i];

					const referentChildren = Chunk.Hierarchy[ParentReferent] ??= [];
					referentChildren.push(ChildReferent);

					// Game
					const
						Parent = Instances[ParentReferent],
						Child = Instances[ChildReferent];
					if (Parent != null) {
						Child.Parent = Parent;

						const ParentChildren = Parent.Children ??= [];
						ParentChildren.push(Child);
					}
					//
				};

				break;
			};

			case "END\x00": {
				Processing = false;
				break;
			};
		};

		Chunks[ChunkSignature].push(Chunk);
	};

	return {
		Headers,
		Chunks,
		Game,
		Instances,
	};
};